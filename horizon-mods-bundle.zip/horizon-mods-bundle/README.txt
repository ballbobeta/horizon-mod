Combat Hitboxes + Multi Key Bindings for Horizon (Rust native mods)
1. Put this folder anywhere. 2. Double-click build.bat (or run:
   horizon-launcher native-build <this folder>\mods --trust-native-code)
First build takes 20-30 minutes (Rust is downloaded by the launcher).
If it complains about the Horizon version, add --allow-version-mismatch.
Then play the "Native mods" instance.
Combat Hitboxes: Options > Mods. Multi Key Bindings: /multikey add x attack
Both are untested against the full game build; send the error if it fails.
