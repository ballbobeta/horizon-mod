// Combat Hitboxes' row in Options > Mods.
fn combat_hitboxes_listed(mods: &mut Vec<crate::game::native_hooks::NativeMod>) {
    use crate::game::combat_hitboxes as ch;
    mods.push(crate::game::native_hooks::NativeMod {
        id: ch::ID.into(),
        title: format!("Combat Hitboxes {}", ch::VERSION),
        description: ch::DESCRIPTION.into(),
        keys: Vec::new(),
    });
}
