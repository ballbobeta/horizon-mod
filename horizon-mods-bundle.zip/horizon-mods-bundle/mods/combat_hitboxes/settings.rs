// Combat Hitboxes' settings page.
fn combat_hitboxes_page(game: &mut crate::game::Game<'_>, mod_id: &str, buttons: &mut Vec<String>) {
    use crate::game::combat_hitboxes as ch;
    if mod_id != ch::ID {
        return;
    }
    let game = &*game;
    let settings = ch::settings(|key| game.native_setting(ch::ID, key));
    buttons.extend(settings.labels());
}
