// Combat Hitboxes for Horizon: a native Rust port of Sootysplash's Fabric mod
// (Apache-2.0). It redraws entity hitboxes to help with attack timing and
// judging reach: a white box, a red eye-height slab, a blue look line, the
// box you are aiming at in red, and hurt entities in magenta.
//
// This file is both the mod's Cargo library (its tests) and the module the
// bundle adds to the game, so it only uses plain arrays and `std`.
use std::cell::RefCell;

pub const ID: &str = "combat_hitboxes";
pub const VERSION: &str = "1.0.11";
pub const DESCRIPTION: &str = "Hitboxes that help with attack timing and gauging your reach: \
    the box you aim at, hurt entities, eye height and look direction.";

// Java's `Color.getRGB()` values of the original defaults.
pub const RED: u32 = 0xFFFF_0000;
pub const BLUE: u32 = 0xFF00_00FF;
pub const WHITE: u32 = 0xFFFF_FFFF;
pub const MAGENTA: u32 = 0xFFFF_00FF;
pub const BLACK: u32 = 0xFF00_0000;

/// The original Config, field for field.
#[derive(Clone, Debug, PartialEq)]
pub struct Settings {
    pub enabled: bool,
    pub hide_items: bool,
    pub change_target_color: bool,
    pub hit_box_hurt: bool,
    pub render_eye_height: bool,
    pub render_look_dir: bool,
    pub line_look_dir: bool,
    pub outline_enabled: bool,
    pub eye_color: u32,
    pub look_color: u32,
    pub hit_box_color: u32,
    pub target_box_color: u32,
    pub hurt_box_color: u32,
    pub outline_color: u32,
    /// Line width up to `dist_for_2` blocks, and beyond it.
    pub line1: f32,
    pub line2: f32,
    pub dist_for_2: f64,
    pub outline_multiplier: f32,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            enabled: true,
            hide_items: false,
            change_target_color: true,
            hit_box_hurt: false,
            render_eye_height: true,
            render_look_dir: true,
            line_look_dir: true,
            outline_enabled: false,
            eye_color: RED,
            look_color: BLUE,
            hit_box_color: WHITE,
            target_box_color: RED,
            hurt_box_color: MAGENTA,
            outline_color: BLACK,
            line1: 2.5,
            line2: 2.5,
            dist_for_2: 32.0,
            outline_multiplier: 2.0,
        }
    }
}

const WIDTHS: [f32; 4] = [1.5, 2.5, 4.0, 6.0];

/// `RRGGBB` or `AARRGGBB`, with an optional `#`; six digits are opaque.
pub fn parse_color(text: &str) -> Option<u32> {
    let t = text.trim().trim_start_matches('#');
    let v = u32::from_str_radix(t, 16).ok()?;
    match t.len() {
        6 => Some(0xFF00_0000 | v),
        8 => Some(v),
        _ => None,
    }
}

pub fn color_text(argb: u32) -> String {
    format!("{argb:08X}")
}

impl Settings {
    /// From the stored values (`get` reads one key); defaults for the missing.
    pub fn read(get: impl Fn(&str) -> Option<String>) -> Self {
        let d = Self::default();
        let flag = |key: &str, default: bool| {
            get(key).map_or(default, |v| match v.trim() {
                "true" => true,
                "false" => false,
                _ => default,
            })
        };
        let color = |key: &str, default: u32| get(key).and_then(|v| parse_color(&v)).unwrap_or(default);
        let num = |key: &str, default: f64, lo: f64, hi: f64| {
            get(key)
                .and_then(|v| v.trim().parse::<f64>().ok())
                .filter(|v| v.is_finite())
                .map_or(default, |v| v.clamp(lo, hi))
        };
        Self {
            enabled: flag("enabled", d.enabled),
            hide_items: flag("hide_items", d.hide_items),
            change_target_color: flag("change_target_color", d.change_target_color),
            hit_box_hurt: flag("hit_box_hurt", d.hit_box_hurt),
            render_eye_height: flag("render_eye_height", d.render_eye_height),
            render_look_dir: flag("render_look_dir", d.render_look_dir),
            line_look_dir: flag("line_look_dir", d.line_look_dir),
            outline_enabled: flag("outline_enabled", d.outline_enabled),
            eye_color: color("eye_color", d.eye_color),
            look_color: color("look_color", d.look_color),
            hit_box_color: color("hit_box_color", d.hit_box_color),
            target_box_color: color("target_box_color", d.target_box_color),
            hurt_box_color: color("hurt_box_color", d.hurt_box_color),
            outline_color: color("outline_color", d.outline_color),
            line1: num("line1", f64::from(d.line1), 0.5, 16.0) as f32,
            line2: num("line2", f64::from(d.line2), 0.5, 16.0) as f32,
            dist_for_2: num("dist_for_2", d.dist_for_2, 0.0, 512.0),
            outline_multiplier: num("outline_multiplier", f64::from(d.outline_multiplier), 1.0, 8.0)
                as f32,
        }
    }

    /// The settings page's buttons.
    pub fn labels(&self) -> Vec<String> {
        let on = |b: bool| if b { "ON" } else { "OFF" };
        vec![
            format!("Combat hitboxes: {}", on(self.enabled)),
            format!("Highlight target: {}", on(self.change_target_color)),
            format!("Highlight hurt: {}", on(self.hit_box_hurt)),
            format!("Eye height: {}", on(self.render_eye_height)),
            format!("Look direction: {}", on(self.render_look_dir)),
            format!("Look as line (off: arrow): {}", on(self.line_look_dir)),
            format!("Outline: {}", on(self.outline_enabled)),
            format!("Hide dropped items: {}", on(self.hide_items)),
            format!("Line width: {}", self.line1),
        ]
    }

    /// A click on button `i` of `labels`.
    pub fn click(&mut self, i: usize) {
        match i {
            0 => self.enabled = !self.enabled,
            1 => self.change_target_color = !self.change_target_color,
            2 => self.hit_box_hurt = !self.hit_box_hurt,
            3 => self.render_eye_height = !self.render_eye_height,
            4 => self.render_look_dir = !self.render_look_dir,
            5 => self.line_look_dir = !self.line_look_dir,
            6 => self.outline_enabled = !self.outline_enabled,
            7 => self.hide_items = !self.hide_items,
            8 => {
                let at = WIDTHS.iter().position(|&w| w == self.line1).unwrap_or(1);
                self.line1 = WIDTHS[(at + 1) % WIDTHS.len()];
                self.line2 = self.line1;
            }
            _ => {}
        }
    }

    /// What to store, key by key. The colours and distances are edited in the
    /// files of the mod's settings folder.
    pub fn stored(&self) -> Vec<(&'static str, String)> {
        let f = |b: bool| if b { "true" } else { "false" }.to_owned();
        vec![
            ("enabled", f(self.enabled)),
            ("hide_items", f(self.hide_items)),
            ("change_target_color", f(self.change_target_color)),
            ("hit_box_hurt", f(self.hit_box_hurt)),
            ("render_eye_height", f(self.render_eye_height)),
            ("render_look_dir", f(self.render_look_dir)),
            ("line_look_dir", f(self.line_look_dir)),
            ("outline_enabled", f(self.outline_enabled)),
            ("eye_color", color_text(self.eye_color)),
            ("look_color", color_text(self.look_color)),
            ("hit_box_color", color_text(self.hit_box_color)),
            ("target_box_color", color_text(self.target_box_color)),
            ("hurt_box_color", color_text(self.hurt_box_color)),
            ("outline_color", color_text(self.outline_color)),
            ("line1", self.line1.to_string()),
            ("line2", self.line2.to_string()),
            ("dist_for_2", self.dist_for_2.to_string()),
            ("outline_multiplier", self.outline_multiplier.to_string()),
        ]
    }
}

thread_local! {
    static SETTINGS: RefCell<Option<Settings>> = const { RefCell::new(None) };
}

/// The settings, read once through `get`, then kept.
pub fn settings(get: impl Fn(&str) -> Option<String>) -> Settings {
    SETTINGS.with_borrow_mut(|s| s.get_or_insert_with(|| Settings::read(get)).clone())
}

/// Replaces the settings (the settings page changed them).
pub fn set_settings(settings: Settings) {
    SETTINGS.with_borrow_mut(|s| *s = Some(settings));
}

/// One entity to draw.
#[derive(Clone, Debug, PartialEq)]
pub struct Subject {
    pub min: [f64; 3],
    pub max: [f64; 3],
    /// Feet position (the look line starts above it).
    pub pos: [f64; 3],
    pub eye_height: f32,
    pub living: bool,
    /// A dropped item (hidden by `hide_items`).
    pub item: bool,
    pub hurt: bool,
    /// Unit view vector.
    pub view: [f64; 3],
}

/// A line to hand to the game's gizmos; `arrow` draws an arrow head.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Seg {
    pub start: [f64; 3],
    pub end: [f64; 3],
    pub color: u32,
    pub width: f32,
    pub arrow: bool,
}

/// The twelve edges of a box.
pub fn cuboid(min: [f64; 3], max: [f64; 3], color: u32, width: f32, out: &mut Vec<Seg>) {
    let c = |x: usize, y: usize, z: usize| [[min[0], max[0]][x], [min[1], max[1]][y], [min[2], max[2]][z]];
    let mut edge = |a: [f64; 3], b: [f64; 3]| {
        out.push(Seg { start: a, end: b, color, width, arrow: false });
    };
    for a in 0..2 {
        for b in 0..2 {
            edge(c(0, a, b), c(1, a, b));
            edge(c(a, 0, b), c(a, 1, b));
            edge(c(a, b, 0), c(a, b, 1));
        }
    }
}

/// Slab test: the distance along `dir` to the box, if within `reach`.
pub fn ray_box(origin: [f64; 3], dir: [f64; 3], min: [f64; 3], max: [f64; 3], reach: f64) -> Option<f64> {
    let (mut near, mut far) = (0.0f64, reach);
    for i in 0..3 {
        if dir[i].abs() < 1e-12 {
            if origin[i] < min[i] || origin[i] > max[i] {
                return None;
            }
            continue;
        }
        let (a, b) = ((min[i] - origin[i]) / dir[i], (max[i] - origin[i]) / dir[i]);
        near = near.max(a.min(b));
        far = far.min(a.max(b));
        if near > far {
            return None;
        }
    }
    Some(near)
}

/// The nearest subject the aim ray reaches.
pub fn target(aim: Option<([f64; 3], [f64; 3])>, reach: f64, subjects: &[Subject]) -> Option<usize> {
    let (origin, dir) = aim?;
    subjects
        .iter()
        .enumerate()
        .filter_map(|(i, s)| ray_box(origin, dir, s.min, s.max, reach).map(|d| (i, d)))
        .min_by(|a, b| a.1.total_cmp(&b.1))
        .map(|(i, _)| i)
}

/// The lines of every subject, as `render_1_21_1_boxes` drew them.
pub fn build(
    s: &Settings,
    eye: [f64; 3],
    aim: Option<([f64; 3], [f64; 3])>,
    reach: f64,
    subjects: &[Subject],
    out: &mut Vec<Seg>,
) {
    if !s.enabled {
        return;
    }
    let targeted = target(aim, reach, subjects);
    for (i, e) in subjects.iter().enumerate() {
        if e.item && s.hide_items {
            continue;
        }
        let d2: f64 = (0..3).map(|k| (e.pos[k] - eye[k]).powi(2)).sum();
        let width = if d2.sqrt() > s.dist_for_2 { s.line2 } else { s.line1 };
        let color = if e.living && e.hurt && s.hit_box_hurt {
            s.hurt_box_color
        } else if s.change_target_color && targeted == Some(i) {
            s.target_box_color
        } else {
            s.hit_box_color
        };
        if (s.outline_enabled && s.outline_color >> 24 != 0) || color >> 24 != 0 {
            if s.outline_enabled && s.outline_color >> 24 != 0 {
                cuboid(e.min, e.max, s.outline_color, width * s.outline_multiplier, out);
            }
            if color >> 24 != 0 {
                cuboid(e.min, e.max, color, width, out);
            }
        }
        if e.living && s.render_eye_height {
            let eye_y = e.min[1] + f64::from(e.eye_height);
            let d = 0.01;
            cuboid(
                [e.min[0], eye_y - d, e.min[2]],
                [e.max[0], eye_y + d, e.max[2]],
                s.eye_color,
                width,
                out,
            );
        }
        if s.render_look_dir {
            let start = [e.pos[0], e.pos[1] + f64::from(e.eye_height), e.pos[2]];
            let end = [
                start[0] + e.view[0] * 2.0,
                start[1] + e.view[1] * 2.0,
                start[2] + e.view[2] * 2.0,
            ];
            out.push(Seg { start, end, color: s.look_color, width, arrow: !s.line_look_dir });
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn subject(x: f64, z: f64) -> Subject {
        Subject {
            min: [x - 0.3, 0.0, z - 0.3],
            max: [x + 0.3, 1.8, z + 0.3],
            pos: [x, 0.0, z],
            eye_height: 1.62,
            living: true,
            item: false,
            hurt: false,
            view: [0.0, 0.0, 1.0],
        }
    }

    #[test]
    fn a_box_has_twelve_edges() {
        let mut out = Vec::new();
        cuboid([0.0; 3], [1.0; 3], WHITE, 2.5, &mut out);
        assert_eq!(out.len(), 12);
        assert!(out.iter().all(|s| (0..3).map(|k| (s.end[k] - s.start[k]).abs()).sum::<f64>() == 1.0));
    }

    #[test]
    fn the_ray_picks_the_nearest_box_within_reach() {
        let subs = [subject(0.0, 5.0), subject(0.0, 3.0), subject(2.0, 3.0)];
        let aim = Some(([0.0, 1.0, 0.0], [0.0, 0.0, 1.0]));
        assert_eq!(target(aim, 6.0, &subs), Some(1));
        assert_eq!(target(aim, 2.0, &subs), None);
        assert_eq!(target(None, 6.0, &subs), None);
    }

    #[test]
    fn the_target_is_red_and_the_rest_white() {
        let s = Settings { render_eye_height: false, render_look_dir: false, ..Settings::default() };
        let subs = [subject(0.0, 3.0), subject(5.0, 3.0)];
        let mut out = Vec::new();
        build(&s, [0.0, 1.0, 0.0], Some(([0.0, 1.0, 0.0], [0.0, 0.0, 1.0])), 6.0, &subs, &mut out);
        assert_eq!(out.len(), 24);
        assert!(out[..12].iter().all(|l| l.color == RED));
        assert!(out[12..].iter().all(|l| l.color == WHITE));
    }

    #[test]
    fn hurt_wins_over_target_when_on() {
        let s = Settings { hit_box_hurt: true, render_eye_height: false, render_look_dir: false, ..Settings::default() };
        let mut e = subject(0.0, 3.0);
        e.hurt = true;
        let mut out = Vec::new();
        build(&s, [0.0; 3], Some(([0.0, 1.0, 0.0], [0.0, 0.0, 1.0])), 6.0, &[e], &mut out);
        assert!(out.iter().all(|l| l.color == MAGENTA));
    }

    #[test]
    fn eye_slab_look_line_and_outline() {
        let s = Settings { outline_enabled: true, ..Settings::default() };
        let mut out = Vec::new();
        build(&s, [0.0; 3], None, 6.0, &[subject(0.0, 3.0)], &mut out);
        // outline box + box + eye slab + look line
        assert_eq!(out.len(), 12 * 3 + 1);
        assert_eq!(out[0].color, BLACK);
        assert_eq!(out[0].width, 5.0);
        let look = out.last().unwrap();
        assert_eq!(look.color, BLUE);
        assert!(!look.arrow);
        assert_eq!(look.end[2] - look.start[2], 2.0);
    }

    #[test]
    fn far_boxes_use_the_second_width_and_items_can_hide() {
        let s = Settings { line1: 1.5, line2: 4.0, hide_items: true, ..Settings::default() };
        let mut item = subject(0.0, 100.0);
        item.item = true;
        item.living = false;
        let mut out = Vec::new();
        build(&s, [0.0; 3], None, 6.0, &[item.clone()], &mut out);
        assert!(out.is_empty());
        let far = subject(0.0, 100.0);
        build(&s, [0.0; 3], None, 6.0, &[far], &mut out);
        assert_eq!(out[0].width, 4.0);
    }

    #[test]
    fn settings_round_trip_and_colours_parse() {
        let mut s = Settings::default();
        s.click(8);
        s.click(0);
        s.eye_color = 0x8012_3456;
        let pairs = s.stored();
        let read = Settings::read(|k| pairs.iter().find(|p| p.0 == k).map(|p| p.1.clone()));
        assert_eq!(read, s);
        assert_eq!(parse_color("#00ff00"), Some(0xFF00_FF00));
        assert_eq!(parse_color("80123456"), Some(0x8012_3456));
        assert_eq!(parse_color("xyz"), None);
        assert_eq!(Settings::read(|_| None), Settings::default());
    }
}
