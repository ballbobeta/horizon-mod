// A click on Combat Hitboxes' settings page: change the setting and keep it.
fn combat_hitboxes_click(game: &mut crate::game::Game<'_>, mod_id: &str, button: usize) {
    use crate::game::combat_hitboxes as ch;
    if mod_id != ch::ID {
        return;
    }
    let mut settings = ch::settings(|key| game.native_setting(ch::ID, key));
    settings.click(button);
    ch::set_settings(settings.clone());
    for (key, value) in settings.stored() {
        game.native_set_setting(ch::ID, key, &value);
    }
}
