// The combat hitboxes, added to the frame's gizmos (F3+B's renderer is left
// alone: while it is on, Horizon's own boxes are what you see).
fn combat_hitboxes_boxes(
    game: &crate::game::Game<'_>,
    alpha: f32,
    mut gizmos: horizon_client::gizmos::Gizmos,
) -> horizon_client::gizmos::Gizmos {
    use crate::game::combat_hitboxes as ch;
    let settings = ch::settings(|key| game.native_setting(ch::ID, key));
    if !settings.enabled || game.debug_entry("entity_hitboxes") {
        return gizmos;
    }
    let Some(eye) = game.eye_position() else {
        return gizmos;
    };
    let aim = game.aim();
    let reach = game.entity_reach;
    let lerp = |a: f64, b: f64| a + f64::from(alpha) * (b - a);
    let lerpf = |a: f32, b: f32| a + alpha * (b - a);
    let mut subjects: Vec<ch::Subject> = Vec::new();
    let guests = game.lan.iter().flat_map(|h| h.models.values());
    for m in game.mobs.iter().chain(guests) {
        if m.removed || m.invisible || m.has_effect("minecraft:invisibility") {
            continue;
        }
        let pos = [
            lerp(m.previous.x, m.position.x),
            lerp(m.previous.y, m.position.y),
            lerp(m.previous.z, m.position.z),
        ];
        let (w, h) = (f64::from(m.width()), f64::from(m.height()));
        let view = horizon_client::gizmos::view_vector(
            lerpf(m.previous_head_pitch, m.head_pitch),
            lerpf(m.previous_head_yaw, m.head_yaw),
        );
        subjects.push(ch::Subject {
            min: [pos[0] - w / 2.0, pos[1], pos[2] - w / 2.0],
            max: [pos[0] + w / 2.0, pos[1] + h, pos[2] + w / 2.0],
            pos,
            eye_height: m.eye_height() as f32,
            living: true,
            item: false,
            hurt: m.hurt_time > 0,
            view,
        });
    }
    for item in &game.dropped {
        let pos = [
            lerp(item.previous.x, item.position.x),
            lerp(item.previous.y, item.position.y),
            lerp(item.previous.z, item.position.z),
        ];
        subjects.push(ch::Subject {
            min: [pos[0] - 0.125, pos[1], pos[2] - 0.125],
            max: [pos[0] + 0.125, pos[1] + 0.25, pos[2] + 0.125],
            pos,
            eye_height: 0.2125,
            living: false,
            item: true,
            hurt: false,
            view: [0.0, 0.0, 0.0],
        });
    }
    let mut segs = Vec::new();
    ch::build(&settings, eye, aim, reach, &subjects, &mut segs);
    for s in segs {
        if s.arrow {
            gizmos.arrow(s.start, s.end, s.color, s.width);
        } else {
            gizmos.line(s.start, s.end, s.color, s.width);
        }
    }
    gizmos
}
