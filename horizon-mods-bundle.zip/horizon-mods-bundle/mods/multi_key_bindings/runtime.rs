// Multi Key Bindings for Horizon: a native Rust port of kennybc's Fabric mod
// (CC0-1.0) core feature, several keys for the same action. An extra key acts
// exactly as the key its action is bound to. Managed with chat commands:
//   /multikey add <key> <action>     e.g. /multikey add x attack
//   /multikey remove <key>
//   /multikey list
// Plain `std` only: this file is also the mod's Cargo library (its tests).
use std::cell::RefCell;

pub const ID: &str = "multi_key_bindings";
pub const VERSION: &str = "1.3.5";
pub const DESCRIPTION: &str = "Several keys for one action. Chat: /multikey add <key> <action>, \
    /multikey remove <key>, /multikey list.";
/// The settings key the list is kept under.
pub const STORE: &str = "binds";

/// `x` -> `key.keyboard.x`; `key.mouse.4` and `key.keyboard.x` stay as given.
pub fn normalize_key(text: &str) -> String {
    let t = text.trim().to_ascii_lowercase();
    if t.starts_with("key.") { t } else { format!("key.keyboard.{t}") }
}

/// `attack` -> `key.attack`.
pub fn normalize_action(text: &str) -> String {
    let t = text.trim().to_ascii_lowercase();
    if t.starts_with("key.") { t } else { format!("key.{t}") }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Extras {
    /// (key name, action name), at most one action per extra key.
    pub pairs: Vec<(String, String)>,
}

impl Extras {
    pub fn parse(text: &str) -> Self {
        let pairs = text
            .split(';')
            .filter_map(|p| p.split_once('='))
            .filter(|(k, a)| !k.trim().is_empty() && !a.trim().is_empty())
            .map(|(k, a)| (k.trim().to_owned(), a.trim().to_owned()))
            .collect();
        Self { pairs }
    }
    pub fn text(&self) -> String {
        self.pairs.iter().map(|(k, a)| format!("{k}={a}")).collect::<Vec<_>>().join(";")
    }
    pub fn add(&mut self, key: &str, action: &str) {
        self.pairs.retain(|(k, _)| k != key);
        self.pairs.push((key.to_owned(), action.to_owned()));
    }
    pub fn remove(&mut self, key: &str) -> bool {
        let before = self.pairs.len();
        self.pairs.retain(|(k, _)| k != key);
        self.pairs.len() != before
    }
    pub fn action_of(&self, key: &str) -> Option<&str> {
        self.pairs.iter().find(|(k, _)| k == key).map(|(_, a)| a.as_str())
    }
}

thread_local! {
    static EXTRAS: RefCell<Option<Extras>> = const { RefCell::new(None) };
}

/// The extra keys, read once through `get` (the stored text), then kept.
pub fn extras(get: impl Fn(&str) -> Option<String>) -> Extras {
    EXTRAS.with_borrow_mut(|e| {
        e.get_or_insert_with(|| Extras::parse(&get(STORE).unwrap_or_default())).clone()
    })
}

pub fn set_extras(extras: Extras) {
    EXTRAS.with_borrow_mut(|e| *e = Some(extras));
}

/// Runs a `multikey ...` chat command; None when it is not ours. `key_ok`
/// and `action_ok` say whether a normalised name exists in the game.
pub fn run(
    extras: &mut Extras,
    line: &str,
    key_ok: impl Fn(&str) -> bool,
    action_ok: impl Fn(&str) -> bool,
) -> Option<Vec<String>> {
    let mut words = line.split_whitespace();
    if words.next()? != "multikey" {
        return None;
    }
    let reply = |s: &str| Some(vec![s.to_owned()]);
    match (words.next(), words.next(), words.next(), words.next()) {
        (Some("add"), Some(k), Some(a), None) => {
            let (k, a) = (normalize_key(k), normalize_action(a));
            if !key_ok(&k) {
                return reply(&format!("Multi Key Bindings: unknown key {k}"));
            }
            if !action_ok(&a) {
                return reply(&format!("Multi Key Bindings: unknown action {a}"));
            }
            extras.add(&k, &a);
            reply(&format!("Multi Key Bindings: {k} now also does {a}"))
        }
        (Some("remove"), Some(k), None, None) => {
            let k = normalize_key(k);
            if extras.remove(&k) {
                reply(&format!("Multi Key Bindings: removed {k}"))
            } else {
                reply(&format!("Multi Key Bindings: {k} has no extra binding"))
            }
        }
        (Some("list"), None, None, None) => {
            if extras.pairs.is_empty() {
                return reply("Multi Key Bindings: none yet. /multikey add <key> <action>");
            }
            Some(extras.pairs.iter().map(|(k, a)| format!("{k} -> {a}")).collect())
        }
        _ => reply("Usage: /multikey add <key> <action> | remove <key> | list"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn all(_: &str) -> bool {
        true
    }

    #[test]
    fn names_are_normalised() {
        assert_eq!(normalize_key("X"), "key.keyboard.x");
        assert_eq!(normalize_key("key.mouse.4"), "key.mouse.4");
        assert_eq!(normalize_action("Attack"), "key.attack");
    }

    #[test]
    fn add_replace_remove_and_round_trip() {
        let mut e = Extras::default();
        assert!(run(&mut e, "multikey add x attack", all, all).is_some());
        run(&mut e, "multikey add x jump", all, all);
        run(&mut e, "multikey add c key.sneak", all, all);
        assert_eq!(e.action_of("key.keyboard.x"), Some("key.jump"));
        assert_eq!(Extras::parse(&e.text()), e);
        let r = run(&mut e, "multikey remove x", all, all).unwrap();
        assert!(r[0].contains("removed"));
        assert_eq!(e.pairs.len(), 1);
        let r = run(&mut e, "multikey remove x", all, all).unwrap();
        assert!(r[0].contains("no extra"));
    }

    #[test]
    fn unknown_names_are_refused_and_other_commands_pass() {
        let mut e = Extras::default();
        let r = run(&mut e, "multikey add zzz attack", |k| k != "key.keyboard.zzz", all).unwrap();
        assert!(r[0].contains("unknown key"));
        let r = run(&mut e, "multikey add x nope", all, |a| a != "key.nope").unwrap();
        assert!(r[0].contains("unknown action"));
        assert!(e.pairs.is_empty());
        assert!(run(&mut e, "gamemode creative", all, all).is_none());
        assert!(run(&mut e, "multikey", all, all).unwrap()[0].starts_with("Usage"));
        assert_eq!(run(&mut e, "multikey list", all, all).unwrap().len(), 1);
    }
}
