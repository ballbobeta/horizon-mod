// The row in Options > Mods.
fn multi_key_listed(mods: &mut Vec<crate::game::native_hooks::NativeMod>) {
    use crate::game::multi_key_bindings as mk;
    mods.push(crate::game::native_hooks::NativeMod {
        id: mk::ID.into(),
        title: format!("Multi Key Bindings {}", mk::VERSION),
        description: mk::DESCRIPTION.into(),
        keys: Vec::new(),
    });
}
