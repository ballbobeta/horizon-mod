// /multikey add|remove|list
fn multi_key_command(game: &mut crate::game::Game<'_>, command: &str, ran: &mut bool) {
    use crate::game::multi_key_bindings as mk;
    let mut extras = mk::extras(|k| game.native_setting(mk::ID, k));
    let known = |name: &str| horizon_client::keybinds::key_code(name).is_some();
    let unknown = "key.keyboard.unknown";
    let replies = {
        let keys = &game.settings.keys;
        mk::run(&mut extras, command, known, |a| keys.get(a) != unknown)
    };
    let Some(lines) = replies else {
        return;
    };
    *ran = true;
    mk::set_extras(extras.clone());
    game.native_set_setting(mk::ID, mk::STORE, &extras.text());
    for line in lines {
        game.native_chat(&line);
    }
}
