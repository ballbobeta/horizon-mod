// An extra key acts as the key its action is bound to: the key event is
// translated as that key, so everything bound to it (the action) follows.
fn multi_key_remap(game: &crate::game::Game<'_>, key: winit::keyboard::KeyCode) -> winit::keyboard::KeyCode {
    use crate::game::multi_key_bindings as mk;
    let Some(name) = horizon_client::keybinds::key_name(key) else {
        return key;
    };
    let extras = mk::extras(|k| game.native_setting(mk::ID, k));
    let Some(action) = extras.action_of(name) else {
        return key;
    };
    horizon_client::keybinds::key_code(game.settings.keys.get(action)).unwrap_or(key)
}
