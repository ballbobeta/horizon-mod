@echo off
rem Builds Combat Hitboxes + Multi Key Bindings together into the "Native mods" instance.
rem Edit the next line if horizon-launcher.exe is somewhere else.
set LAUNCHER=horizon-launcher.exe
%LAUNCHER% native-build "%~dp0mods" --trust-native-code
pause
